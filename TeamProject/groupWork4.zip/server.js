//Ju

var http = require("http");
var fs = require("fs");
var httpServer = http.createServer(requestHandler);
httpServer.listen(8080);

function requestHandler (req, res){

        fs.readFile(__dirname + '/index.html',
                function (err, data) {
                        if (err) {
                                res.writeHead(500);
                                return res.end('Error loading index.html');
                        }

                        res.writeHead(200);
                        res.end(data);
                });
}


var io = require('socket.io').listen(httpServer,{log: false});

var users = new Array();
var totalScore = 0;
var threshold;

// Register a callback function to run when we have an individual connection
// This is run for each individual user that connects
io.sockets.on('connection', 
	// We are given a websocket object in our function
	function (socket) {

		console.log("We have a new client: " + socket.id);

		var userId = 1;
		userId = users.length;
		users[users.length] = socket.id;
		console.log(users.length);
		
		// When this user "send" from clientside javascript, we get a "message"
		// client side: socket.send("the message");  or socket.emit('message', "the message");
		socket.on('message', function() {

			for(var i = 0; i < users.length; i++){
				io.sockets.emit('init', userId);
			}
		});

		socket.on('mousecoords', function (data) {
			socket.broadcast.emit('mousecoords', data);
		});

		socket.on('playerscore', function (data) {
			totalScore++;
			//console.log(totalScore);

			if (totalScore = 500) {
				//SEND CODE TO ARDUINO HERE
				//..........

				//SOCKET EMIT - SEND SOMETHING TO CLIENT SIDE SO THERE'S FEEDBACK IN BROWSER TOO
				io.sockets.emit('threshold', totalScore);
			}
		});
		
		socket.on('disconnect', function() {
			console.log("Client has disconnected");
		});
	}
);