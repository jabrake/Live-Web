//Ju

var http = require("http");
var fs = require("fs");
var httpServer = http.createServer(requestHandler);
httpServer.listen(8080);

function requestHandler (req, res){

        fs.readFile(__dirname + '/index.html',
                function (err, data) {
                        if (err) {
                                res.writeHead(500);
                                return res.end('Error loading index.html');
                        }

                        res.writeHead(200);
                        res.end(data);
                });
}


var io = require('socket.io').listen(httpServer,{log: false});

var users = new Array();

var totalScore = 0;
var threshold;
var accX = 0;
var accY = 0;
var velX = 0;
var velY = 0;
var xPos = 450;
var yPos = 250;
var width = 900;
var height = 500;
var radius = 30;

// var randomAcc = function() {
// 	accX = Math.random();
// 	accY = Math.random();
// };

var updateBall = function() {

	accX = Math.random();
    accY = Math.random();

    //console.log(accX);

    velX += accX;
    velY += accY;

    //console.log("velX: " + velX + " velY: " + velY);

    xPos += velX;
    yPos += velY;

    if (xPos + radius >= width || xPos - radius <= 0) {
        velX *= -1;
    }

    if (yPos + radius >= height || yPos - radius <= 0) {
        velY *= -1;
    }
};

setInterval(updateBall, 30);

// Register a callback function to run when we have an individual connection
// This is run for each individual user that connects
io.sockets.on('connection', 
	// We are given a websocket object in our function
	function (socket) {

		console.log("We have a new client: " + socket.id);

		setInterval(function() {
			io.sockets.emit('xPos', xPos);
			io.sockets.emit('yPos', yPos);

			//console.log(xPos, yPos);

		}, 30);

		var userId = -1;
		userId = users.length;
		users[users.length] = socket.id;
		console.log(users.length);
		
		// When this user "send" from clientside javascript, we get a "message"
		// client side: socket.send("the message");  or socket.emit('message', "the message");
		socket.on('message', function() {

			for(var i = 0; i < users.length; i++){
				io.sockets.emit('init', userId);
			}
		});

		socket.on('mousecoords', function (data) {
			io.sockets.emit('mousecoords', data);
			//console.log(data);
		});

		socket.on('playerscore', function (data) {
			totalScore++;
			//console.log(totalScore);

			if (totalScore = 500) {
				//SEND CODE TO ARDUINO HERE
				// var options = {
				// 	host: 'http://128.122.98.22',
				// 	path: '/arduino/digital/13/1'
				// };

				// callback = function(response) {
				// 	response.on('end', function() {
				// 		console.log("Sent data to Arduino!");
				// 	});
				// }

				// http.request(options, callback).end();

				//SOCKET EMIT - SEND SOMETHING TO CLIENT SIDE SO THERE'S FEEDBACK IN BROWSER TOO
				io.sockets.emit('threshold', totalScore);
			}
		});
		
		socket.on('disconnect', function() {
			console.log("Client has disconnected");
		});
	}
);